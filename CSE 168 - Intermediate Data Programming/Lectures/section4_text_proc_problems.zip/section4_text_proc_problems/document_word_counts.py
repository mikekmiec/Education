# Defines a class to count the words in a single document

import re


class DocumentWordCounts:
    '''
    The DocumentWordCounts class represents a document and contains methods
    related to the unique words in this document. Uniqueness is
    case-insensitive and ignores punctuation and non-alphabetic characters.
    (ie. “hello” and “HeLo!?!” are considered the same word.)
    '''

    def __init__(self, fname):
        '''
        Initializes a new DocumentWordCounts object. The fname is the name of
        the file this DocumentWordCounts will represent. You will store all
        words in the unique words in a set.
        '''
        # TODO: Delete this comment and implement this function

    def _compute_unique_words(self, fname):
        '''
        Returns a set of all of the words in the file called fname.
        Uniqueness is case-insensitive and ignores punctuation and
        non-alphabetic characters. (ie. “hello” and “HeLo!?!” are
        considered the same word.)
        '''
        # TODO: Delete this comment and implement this function

    def num_unique_words(self):
        '''
        Returns the number of unique words in this document.
        '''
        # TODO: Delete this comment and implement this function

    def get_fname(self):
        '''
        Returns the name of the document
        '''
        # TODO: Delete this comment and implement this function
