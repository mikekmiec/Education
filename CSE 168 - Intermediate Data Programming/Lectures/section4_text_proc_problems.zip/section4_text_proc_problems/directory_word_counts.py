import os
from document_word_counts import DocumentWordCounts


class DirectoryWordCounts:
    '''
    The DirectoryWordCounts contains information
    on the unique word counts for multiple files.
    '''

    def __init__(self, dir):
        '''
        Constructs a new DirectoryWordCounts object given a directory name.
        '''

        # TODO: Delete this comment and implement this function

    def uniqueness_list(self):
        '''
        Returns a list of the documents in this DirectoryWordCounts as tuples
        (document name, number of unique words) sorted in descending order by
        number of unique words.

        Ie. if DirectoryWordCounts has “a.txt” with 1 unique word and
        “b.txt” with 25 unique words, the list returned should be:
        [(“b.txt”, 25), (“a.txt”, 1)]
        '''

        # TODO: Delete this comment and implement this function and delete
        # the return statement
        return []
